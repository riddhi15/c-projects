<template>
  <div class="w-full pt-24">
    <header
      v-if="showUploading"
      class="fixed mt-6 z-20 flex items-center w-full"
      style="backdrop-filter: blur(5px);background: rgba(255, 255, 255, 0.9);"
    >
      <div class="fixed w-full">
        <div
          class="relative flex w-80 py-2 h-12 px-5 mx-auto rounded visible items-center"
          :class="{
            'bg-red-600': toastType === 'error',
            'bg-rax-gray-dark': toastType === 'info',
            'bg-green-600': toastType === 'success'
          }"
        >
          <img
            v-if="showToastLoading"
            loading="lazy"
            class=" animate-spin mr-2"
            src="~/assets/icons/loading.svg"
          />
          <div class="text-white mr-6">
            {{ toastText }}
          </div>
          <div
            class="text-sm font-medium absolute right-0 mr-6 cursor-pointer"
            :class="{
              'text-rax-black-/40': toastType === 'info',
              'text-white': ['error', 'success'].includes(toastType)
            }"
            @click="cancelClicked"
          >
            {{ toastCloseButtonText }}
          </div>
        </div>
      </div>
    </header>
    <div class="container w-11/12 mx-auto">
      <Banner class="mt-10 mb-20 md::mt-16" />
      <client-only>
        <University />
      </client-only>
    </div>
    <ExpandKnowledge />
    <div class="container w-11/12 mx-auto">
      <MoreToRax />
      <AssistEveryStage />
    </div>
    <ShareAndCollaborate />
    <Testimonials />
    <PrivacyAndSecurity />
    <!-- <client-only>
        <KeyInsights :is-cancelled="isCancelled" @showToast="showToast" />
      </client-only> -->
    <!-- todo: delete this -->
    <div v-if="false">
      <div class="container w-11/12 mx-auto">
        <ComparingProblem />
        <InsightsLostProblem />
        <Critique />
        <Documentation />
        <Problem>
          <template slot="title">
            No easy way to find the right resources as per your current focus?
          </template>
          <template slot="content">
            <div
              class="flex flex-col justify-around w-full rax-font-h4 md:flex-row"
            >
              <div
                class="flex flex-row items-center justify-around pb-10 w-22/24 md:w-10/24 md:flex-col-reverse lg:flex-row md:pb-0"
              >
                <div class="w-3/5 px-4 md:w-4/5 lg:w-3/5">
                  I am not able to find useful papers related to the approach
                  outlined in this paper. Searching across the web takes up a
                  lot of time.
                </div>
                <picture class="w-2/5 md:w-3/5 lg:w-2/5">
                  <source
                    type="image/webp"
                    srcset="~assets/images/home/Problem_3a.webp"
                  />
                  <source
                    type="image/png"
                    srcset="~assets/images/home/Problem_3a.png"
                  />
                  <img
                    loading="lazy"
                    src="~assets/images/home/Problem_3a.png"
                  />
                </picture>
              </div>
              <div
                class="flex flex-row-reverse items-center justify-around w-22/24 md:w-10/24 md:flex-col-reverse lg:flex-row-reverse"
              >
                <div class="w-3/5 px-4 md:w-4/5 lg:w-3/5">
                  I keep getting scholarly article alerts … but most of them are
                  either irrelevant or not related to what I need NOW.
                </div>
                <picture class="w-2/5 md:w-3/5 lg:w-2/5">
                  <source
                    type="image/webp"
                    srcset="~assets/images/home/Problem_3b.webp"
                  />
                  <source
                    type="image/png"
                    srcset="~assets/images/home/Problem_3b.png"
                  />
                  <img
                    loading="lazy"
                    src="~assets/images/home/Problem_3b.png"
                  />
                </picture>
              </div>
            </div>
          </template>
        </Problem>
        <ExpandResearch />
        <Collaborate />
        <Oraganize />
      </div>
      <div
        class="flex items-center justify-center w-full px-5 mt-16 mb-32 bg-rax-black-/2"
      >
        <RAxImporter />
      </div>
      <div class="container w-11/12 mx-auto md:w-auto">
        <Security />
      </div>
    </div>
    <CallToAction />
  </div>
</template>

<script>
import debounce from 'lodash/debounce';
import Banner from '~/components/Home/Banner/Index.vue';
import University from '~/components/Home/University/Index.vue';
import Testimonials from '~/components/Home/Testimonials/Index.vue';
import AssistEveryStage from '~/components/Home/Features/AssistEveryStage.vue';
import CallToAction from '~/components/Home/CallToAction.vue';
import { MixpanelEvents } from '~/shared/constants';
import ExpandKnowledge from '~/components/Home/Features/ExpandKnowledge.vue';
import MoreToRax from '~/components/Home/Features/MoreToRax.vue';
import ShareAndCollaborate from '~/components/Home/Features/ShareAndCollaborate.vue';
import PrivacyAndSecurity from '~/components/Home/Features/PrivacyAndSecurity.vue';

export default {
  components: {
    Banner,
    University,
    Testimonials,
    AssistEveryStage,
    CallToAction,
    ExpandKnowledge,
    MoreToRax,
    ShareAndCollaborate,
    PrivacyAndSecurity
  },
  data() {
    return {
      showUploading: false,
      isCancelled: false,
      showToastLoading: true,
      toastText: '',
      toastCloseButtonText: 'Close',
      toastType: 'info',
      toastTimeout: null,
      handleDebouncedScroll: null
    };
  },
  mounted() {
    this.$mixpanel.track(MixpanelEvents.Home.View);
    this.handleDebouncedScroll = debounce(this.onScroll, 500);
    window.addEventListener('scroll', this.handleDebouncedScroll);
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.handleDebouncedScroll);
  },
  methods: {
    onScroll() {
      this.$mixpanel.track(MixpanelEvents.Home.Scroll);
    },
    showToast(val, payload) {
      this.showUploading = false;
      if (val) {
        clearTimeout(this.toastTimeout);
        this.showToastLoading = payload.showToastLoading;
        this.toastText = payload.text;
        this.toastCloseButtonText = payload.closeButtonText || 'Close';
        this.toastType = payload.type || 'info';
        if (!payload.timeout || payload.timeout > 0) {
          this.toastTimeout = setTimeout(() => {
            this.showUploading = false;
          }, payload.timeout || 3000);
        }
        this.isCancelled = false;
        this.showUploading = true;
      }
    },
    cancelClicked() {
      this.isCancelled = true;
      this.showUploading = false;
    }
  },
  head: {
    title: 'Literature Review and Critical Analysis tool for Researchers | RAx',
    meta: [
      {
        hid: 'description',
        name: 'description',
        content: `RAx - AI-based research assistant helps with discovery, literature review, critical analysis, paper summary and organize research papers. Free Sign-up!`
      },
      {
        name: 'og:type',
        content: 'website'
      },
      {
        name: 'og:title',
        content: 'Literature Review & Critical Analysis Tool for Researchers'
      },
      {
        name: 'og:description',
        content:
          'RAx - Research assistant tool helps with literature review, critical analysis, summarizing, and more.'
      },
      {
        name: 'og:image',
        content: '~assets/images/raxter-logo.png'
      },
      {
        name: 'og:url',
        content: 'https://raxter.io'
      },
      {
        name: 'og:site_name',
        content: 'RAx'
      },
      {
        name: 'og:locale',
        content: 'en_US'
      },
      {
        name: 'twitter:title',
        content: 'Literature Review & Critical Analysis Tool for Researchers'
      },
      {
        name: 'twitter:description',
        content:
          'RAx - Research assistant tool helps with literature review, critical analysis, summarizing, and more.'
      },
      { name: 'twitter:site', content: '@Raxter_io' },
      { name: 'twitter:card', content: 'summary' },
      {
        name: 'twitter:image',
        content: '~assets/images/raxter-logo.png'
      }
    ],
    link: [{ rel: 'canonical', href: 'https://www.raxter.io/' }]
  }
};
</script>

<style lang="scss" scoped>
.animate-spin {
  animation: spin 1s linear infinite;

  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
}
</style>
