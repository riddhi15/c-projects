const ASSETS_URL = process.env.ASSETS_URL || 'https://assets.raxter.io/';
export default {
  ssr: 'false',
  target: 'static',
  server: {
    port: process.env.PORT || 3001,
    host: process.env.HOST || '127.0.0.1' // default: localhost
  },
  env: {
    ASSETS_URL: 'https://assets.raxter.io/',
    CookieEnv: process.env.NODE_ENV !== 'production' ? 'beta' : 'live',
    API_URL:
      process.env.NODE_ENV !== 'production'
        ? 'https://beta.api.raxter.io/'
        : 'https://api.raxter.io/',
    ASSISTANT_URL:
      process.env.NODE_ENV !== 'production'
        ? 'https://beta.assistant.raxter.io/'
        : 'https://assistant.raxter.io/',
    BASE_URL:
      process.env.NODE_ENV !== 'production'
        ? 'https://beta.raxter.io'
        : 'https://raxter.io',
    SERVERLESS_BASE_URL:
      process.env.NODE_ENV !== 'production'
        ? 'https://beta.serverless.raxter.io'
        : 'https://serverless.raxter.io',
    USER_UPLOADS_BUCKET:
      process.env.NODE_ENV !== 'production'
        ? 'user-files-beta'
        : 'user-files-live',
    S3_USER_ACCESS_KEY: 'AKIASXD4D6IHLGPFRPFZ', // beta & live
    // MIXPANEL_TOKEN: 'efc5ee9066b2a5e29915a3b2994bed3f', // dev
    MIXPANEL_TOKEN:
      process.env.NODE_ENV !== 'production'
        ? '91df44bee912807c26a3d7717a2b7931'
        : 'ca5666fd3aecd9f749ff373f967dc840'
  },
  /*
   ** Headers of the page
   */
  head: {
    htmlAttrs: {
      lang: 'en'
    },
    headAttrs: {
      lang: 'en'
    },
    title: '',
    titleTemplate: titleChunk => {
      return titleChunk
        ? `${titleChunk}`
        : 'RAx - The Research Tool for Literature Review, and Analysis.';
    },
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      {
        hid: 'description',
        name: 'description',
        content:
          'RAx helps researchers with literature review, analysis, critical analysis, finding insight/educational resources/organizing research papers, and collaboration.'
      },
      {
        name: 'keywords',
        content:
          'personal research assistant, literature review, research paper writing, research methods, productivity, research tools, literature review in research, literature analysis, literature review in research paper, critical analysis, reading papers, note taking software, research paper search'
      },
      { name: 'robots', content: 'INDEX, FOLLOW' },
      { name: 'application-name', content: 'RAx' },
      { name: 'apple-mobile-web-app-title', content: 'RAx' },
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'mobile-web-app-capable', content: 'yes' },
      {
        name: 'apple-mobile-web-app-status-bar-style',
        content: 'black-translucent'
      },
      { name: 'theme-color', content: '#1A64E2' },
      { name: 'apple-mobile-web-app-status-bar-style', content: '#1A64E2' },
      { name: 'msapplication-TileColor', content: '#1A64E2' },
      { name: 'msapplication-navbutton-color', content: '#1A64E2' },
      { name: 'msapplication-TileImage', content: 'ms-icon-144x144.png' }
    ],
    link: [
      { rel: 'manifest', href: `/manifest.json` },
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
      {
        rel: 'apple-touch-icon',
        sizes: '57x57',
        href: `${ASSETS_URL}img/favicon-57x57.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '60x60',
        href: `${ASSETS_URL}img/favicon-60x60.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '72x72',
        href: `${ASSETS_URL}img/favicon-72x72.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '76x76',
        href: `${ASSETS_URL}img/favicon-76x76.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '114x114',
        href: `${ASSETS_URL}img/favicon-114x114.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '120x120',
        href: `${ASSETS_URL}img/favicon-120x120.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '144x144',
        href: `${ASSETS_URL}img/favicon-144x144.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '152x152',
        href: `${ASSETS_URL}img/favicon-152x152.png`
      },
      {
        rel: 'apple-touch-icon',
        sizes: '180x180',
        href: `${ASSETS_URL}img/favicon-180x180.png`
      },
      {
        rel: 'icon',
        type: 'image/png',
        sizes: '192x192',
        href: `${ASSETS_URL}img/favicon-192x192.png`
      },
      {
        rel: 'icon',
        type: 'image/png',
        sizes: '96x96',
        href: `${ASSETS_URL}img/favicon-96x96.png`
      },
      {
        rel: 'icon',
        type: 'image/png',
        sizes: '32x32',
        href: `${ASSETS_URL}img/favicon-32x32.png`
      },
      {
        rel: 'icon',
        type: 'image/png',
        sizes: '16x16',
        href: `${ASSETS_URL}img/favicon-16x16.png`
      }
    ]
  },
  /*
   ** Customize the progress-bar color
   */
  loading: { color: '#1A64E2' },
  /*
   ** Global CSS
   */
  css: [],
  /*
   ** Plugins to load before mounting the App
   */
  plugins: [
    { src: '~plugins/nuxt-video-player-plugin.js', ssr: false },
    { src: '~plugins/vue-js-modal.js', ssr: false },
    { src: '~plugins/VTooltip.js', ssr: false },
    { src: '~plugins/icons.js', ssr: true },
    { src: '~plugins/vue-observe-visibility.js', ssr: false },
    { src: '~/plugins/zoho.js', ssr: false },
    { src: '~/plugins/mixpanel.js', ssr: false }
  ],
  /*
   ** Nuxt.js dev-modules
   */
  buildModules: [
    '@nuxtjs/eslint-module',
    '@nuxtjs/tailwindcss',
    '@nuxtjs/google-analytics',
    [
      '@nuxtjs/google-fonts',
      {
        families: {
          Inter: {
            wght: [400, 500, 600, 700],
            display: 'swap'
          }
        }
      }
    ]
  ],

  gtm: {
    id: process.env.NODE_ENV !== 'production' ? '' : 'GTM-5FFQXWW'
  },
  'google-gtag': {
    id: process.env.NODE_ENV !== 'production' ? '' : 'GTM-5FFQXWW'
  },
  googleAnalytics: {
    id: process.env.NODE_ENV !== 'production' ? '' : 'UA-115936266-1'
  },
  /*
   ** Nuxt.js modules
   */
  modules: [
    '@nuxtjs/axios',
    '@nuxtjs/dotenv',
    '@nuxtjs/svg',
    'nuxt-material-design-icons-iconfont',
    '@nuxtjs/gtm',
    '@nuxtjs/google-gtag',
    '@nuxtjs/sitemap',
    '@nuxtjs/robots'
  ],
  /*
   ** Axios module configuration
   ** See https://axios.nuxtjs.org/options
   */
  axios: {},
  /*
   ** Build configuration
   */
  build: {
    extend(config, ctx) {
      config.module.rules.push({
        test: /\.(mkv|m4v)$/i,
        loader: 'file-loader',
        options: {
          name: '[path][name].[ext]'
        }
      });
    }
  },
  render: {
    bundleRenderer: {
      shouldPreload: (file, type) => {
        return ['script', 'style', 'font'].includes(type);
      }
    }
  },
  router: {
    linkExactActiveClass: 'text-rax-blue font-semibold'
  },
  sitemap: {
    hostname: process.env.BASE_URL || 'https://www.raxter.io',
    gzip: true,
    exclude: ['/**'],
    routes: [
      {
        url: '/',
        changefreq: 'daily',
        priority: 1
      },
      {
        url: '/teams/',
        changefreq: 'daily',
        priority: 1
      },
      {
        url: '/pricing/',
        changefreq: 'daily',
        priority: 1
      },
      {
        url: '/for-librarians/',
        changefreq: 'daily',
        priority: 1
      },
      {
        url: '/review-assistant/',
        changefreq: 'daily',
        priority: 1
      },
      {
        url: '/features/',
        changefreq: 'daily',
        priority: 1
      },
      {
        url: '/referral/',
        changefreq: 'daily',
        priority: 0.8
      },
      {
        url: '/faq/',
        changefreq: 'daily',
        priority: 0.7
      },
      {
        url: '/about-us/',
        changefreq: 'daily',
        priority: 0.5
      },
      {
        url: '/contact-us/',
        changefreq: 'daily',
        priority: 0.5
      },
      {
        url: '/privacy/',
        changefreq: 'daily',
        priority: 0.5
      },
      {
        url: '/terms/',
        changefreq: 'daily',
        priority: 0.5
      }
    ]
  },
  robots: [
    {
      UserAgent: '*',
      Disallow: ['beta.raxter.io', 'console.raxter.io']
    },
    {
      Sitemap: 'https://www.raxter.io/sitemap.xml'
    },
    {
      Sitemap: 'https://blog.raxter.io/sitemap.xml'
    }
  ]
};
