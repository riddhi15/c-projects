import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { FeaturesComponent } from './Components/features/features.component';
import { ConsistencyChecksComponent } from './Components/features/consistency-checks/consistency-checks.component';
import { PersonalDictionaryComponent } from './Components/features/personal-dictionary/personal-dictionary.component';
import { ExamplesComponent } from './Components/examples/examples.component';
import { PricingComponent } from './Components/pricing/pricing.component';
import { EnterpriseComponent } from './Components/enterprise/enterprise.component';
import { LifeSciencesMedicineAndPharmaComponent } from './Components/life-sciences-medicine-and-pharma/life-sciences-medicine-and-pharma.component';
import { LanguageServicesPublishingAndMediaComponent } from './Components/language-services-publishing-and-media/language-services-publishing-and-media.component';
import { AcademicInstitutionsComponent } from './Components/academic-institutions/academic-institutions.component';
import { K12AndElearningComponent } from './Components/k12-and-elearning/k12-and-elearning.component';
import { TechnologyPlatformsComponent } from './Components/technology-platforms/technology-platforms.component';
import { wordpluginComponent } from './Components/word-plugin/word-plugin.component';
import { TrinkaCloudComponent } from './Components/trinka-cloud/trinka-cloud.component';
import { AboutUsComponent } from './Components/about-us/about-us.component';
import { ContactUsComponent } from './Components/contact-us/contact-us.component';
import { WorkWithUsComponent } from './Components/work-with-us/work-with-us.component';
import { PrivacyPolicyComponent } from './Components/privacy-policy/privacy-policy.component';
import { TermServicesComponent } from './Components/term-services/term-services.component';
import { GcEditorComponent } from './Components/gc-editor/gc-editor.component';
import { WhitePaperComponent } from './Components/white-paper/white-paper.component';
import { PageNotFoundComponent } from './Components/page-not-found/page-not-found.component';
import { AutoEditComponent } from './Components/auto-edit/auto-edit.component';
import { AffiliatesComponent } from './Components/affiliates/affiliates.component';
import { BrowserPluginComponent } from './Components/browser-plugin/browser-plugin.component';
import { PublicationChecksComponent } from './Components/publication-checks/publication-checks.component';
import { ReferralComponent } from './Components/referral/referral.component';
import { BrandComponent } from './Components/brand/brand.component';
import { TryADemoComponent } from './Components/try-ademo/try-ademo.component';
import { ProfessionalEditingServiceComponent } from './Components/professional-editing-service/professional-editing-service.component';
import { TrinkaVsGrammarlyComponent } from './Components/trinka-vs-grammarly/TrinkaVsGrammarlyComponent';
import { TrinkaVsGingerComponent } from './Components/trinka-vs-ginger/trinka-vs-ginger.component';
import { TrinkaVsLanguagetoolComponent } from './Components/trinka-vs-languagetool/trinka-vs-languagetool.component';
import { TrinkaVsWritefullComponent } from './Components/trinka-vs-writefull/trinka-vs-writefull.component';
import { FAQComponent } from './Components/faq/faq.component';
import { PowerModeEditingComponent } from './Components/power-mode-editing/power-mode-editing.component';
import { WebinarOneComponent } from './Components/webinar/webinar-one/webinar-one.component';
import { AccomplishmentsComponent } from './Components/accomplishments/accomplishments.component';
import { MedicalSaComponent } from './Components/medical-sa/medical-sa.component';
import { AcademicPhrasebankComponent } from './Components/academic-phrasebank/academic-phrasebank.component';
import { AcademicPhrasebankBrowseComponent } from './Components/academic-phrasebank-browse/academic-phrasebank-browse.component';
import { CreditsComponent } from './Components/features/credits/credits.component';
const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: "features", component: FeaturesComponent },
  { path: "features/consistency-check", component: ConsistencyChecksComponent },
  { path: "features/personal-dictionary", component: PersonalDictionaryComponent },
  { path: "features/publication-readiness-checks", component: PublicationChecksComponent },
  { path: "features/auto-file-edit", component: AutoEditComponent },
  { path: "examples", component: ExamplesComponent },
  { path: "pricing", component: PricingComponent },
  { path: "enterprise", component: EnterpriseComponent },
  { path: "enterprise/life-sciences-medicine-and-pharma", component: LifeSciencesMedicineAndPharmaComponent },
  { path: "enterprise/language-services-publishing-and-media", component: LanguageServicesPublishingAndMediaComponent },
  { path: "enterprise/academic-institutions", component: AcademicInstitutionsComponent },
  { path: "enterprise/k12-and-elearning", component: K12AndElearningComponent },
  { path: "enterprise/technology-platforms", component: TechnologyPlatformsComponent },
  { path: "wordplugin", component: wordpluginComponent },
  { path: "trinkacloud", component: TrinkaCloudComponent },
  { path: "aboutus", component: AboutUsComponent },
  { path: "contactus", component: ContactUsComponent },
  { path: "workwithus", component: WorkWithUsComponent },
  { path: "privacypolicy", component: PrivacyPolicyComponent },
  { path: "termsofservices", component: TermServicesComponent },
  { path: "try-a-demo", component: TryADemoComponent },
  { path: "trinka-vs-grammarly-vs-language-tool", component: WhitePaperComponent },
  { path: "professional-editing-service", component: ProfessionalEditingServiceComponent },
  { path: "affiliates", component: AffiliatesComponent },
  { path: "browser-plugin", component: BrowserPluginComponent },
  { path: "trinka-vs-grammarly", component: TrinkaVsGrammarlyComponent },
  { path: "trinka-vs-ginger", component: TrinkaVsGingerComponent },
  { path: "trinka-vs-languagetool", component: TrinkaVsLanguagetoolComponent },
  { path: "trinka-vs-writefull", component: TrinkaVsWritefullComponent },
  { path: "referral", component: ReferralComponent },
  { path: "brand-list", component: BrandComponent },
  { path: "faqs", component: FAQComponent },
  // { path: "power-mode-editing", component: PowerModeEditingComponent },
  { path: "webinar/Three-ways-in-which-you-can-harness-the-power-of-AI-in-scholarly-publishing", component: WebinarOneComponent },
  { path: "accomplishments", component: AccomplishmentsComponent },
  { path: "medical-grammar-and-spelling-checker", component: MedicalSaComponent },
  { path: "grammar-checker", component: GcEditorComponent },
  { path: "academic-phrasebank", component: AcademicPhrasebankComponent },
  { path: "academic-phrasebank-browse", component: AcademicPhrasebankBrowseComponent },
  { path: "features/credits", component: CreditsComponent },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    initialNavigation: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }