import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import {Location} from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { HeaderComponent } from './Shared/header/header.component';
import { FooterComponent } from './Shared/footer/footer.component';
import { HomeComponent } from './Components/home/home.component';
import { FeaturesComponent } from './Components/features/features.component';
import { ExamplesComponent } from './Components/examples/examples.component';
import { PricingComponent } from './Components/pricing/pricing.component';
import { EnterpriseComponent } from './Components/enterprise/enterprise.component';

import { wordpluginComponent } from './Components/word-plugin/word-plugin.component';
import { TrinkaCloudComponent } from './Components/trinka-cloud/trinka-cloud.component';
import { AboutUsComponent } from './Components/about-us/about-us.component';
import { ContactUsComponent } from './Components/contact-us/contact-us.component';
import { WorkWithUsComponent } from './Components/work-with-us/work-with-us.component';
import { PrivacyPolicyComponent } from './Components/privacy-policy/privacy-policy.component';
import { TermServicesComponent } from './Components/term-services/term-services.component';
import { PageNotFoundComponent } from './Components/page-not-found/page-not-found.component';
import { GcEditorComponent } from './Components/gc-editor/gc-editor.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './models/material-components.service';
import { HttpClientModule } from '@angular/common/http';
import { CKEditorModule } from 'ngx-ckeditor';
import { ToastrModule } from 'ngx-toastr';
import { MaterialModuleList } from './material-module';
import { NgtUniversalModule } from '@ng-toolkit/universal';
import { AppComponent } from './app.component';
import { TransferHttpCacheModule } from '@nguniversal/common';
import { ReferralComponent } from './Components/referral/referral.component';
import { ProfessionalEditingServiceComponent } from './Components/professional-editing-service/professional-editing-service.component';
import { TrinkaVsGrammarlyComponent } from './Components/trinka-vs-grammarly/TrinkaVsGrammarlyComponent';
import { TrinkaVsLanguagetoolComponent } from './Components/trinka-vs-languagetool/trinka-vs-languagetool.component';
import { TrinkaVsGingerComponent } from './Components/trinka-vs-ginger/trinka-vs-ginger.component';
import { TrinkaVsWritefullComponent } from './Components/trinka-vs-writefull/trinka-vs-writefull.component';
import { BrowserPluginComponent } from './Components/browser-plugin/browser-plugin.component';
import { BrandComponent } from './Components/brand/brand.component';
import { FAQComponent } from './Components/faq/faq.component';
import { WebinarOneComponent } from './Components/webinar/webinar-one/webinar-one.component';
import { AccomplishmentsComponent } from './Components/accomplishments/accomplishments.component';
import { AutoEditComponent } from './Components/auto-edit/auto-edit.component';
import { PowerModeEditingComponent } from './Components/power-mode-editing/power-mode-editing.component';
import { PublicationChecksComponent } from './Components/publication-checks/publication-checks.component';
import { LifeSciencesMedicineAndPharmaComponent } from './Components/life-sciences-medicine-and-pharma/life-sciences-medicine-and-pharma.component';
import { LanguageServicesPublishingAndMediaComponent } from './Components/language-services-publishing-and-media/language-services-publishing-and-media.component';
import { AcademicInstitutionsComponent } from './Components/academic-institutions/academic-institutions.component';
import { K12AndElearningComponent } from './Components/k12-and-elearning/k12-and-elearning.component';
import { TechnologyPlatformsComponent } from './Components/technology-platforms/technology-platforms.component';
import { AcademicPhrasebankComponent } from './Components/academic-phrasebank/academic-phrasebank.component';
import { AcademicPhrasebankBrowseComponent } from './Components/academic-phrasebank-browse/academic-phrasebank-browse.component';
import { HighlightKeywordsDirective } from "./_directives/highlightKeywords.directive";
import { PaginationComponent } from "./Components/pagination/pagination.component";
import { ConsistencyChecksComponent } from './Components/features/consistency-checks/consistency-checks.component';
import { PersonalDictionaryComponent } from './Components/features/personal-dictionary/personal-dictionary.component';
import { CreditsComponent } from './Components/features/credits/credits.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    FeaturesComponent,
    ExamplesComponent,
    PricingComponent,
    EnterpriseComponent,
    wordpluginComponent,
    TrinkaCloudComponent,
    AboutUsComponent,
    ContactUsComponent,
    WorkWithUsComponent,
    PrivacyPolicyComponent,
    TermServicesComponent,
    PageNotFoundComponent,
    GcEditorComponent,
    ReferralComponent,
    ProfessionalEditingServiceComponent,
    TrinkaVsGrammarlyComponent,
    TrinkaVsGingerComponent,
    TrinkaVsLanguagetoolComponent,
    TrinkaVsWritefullComponent,
    BrowserPluginComponent,
    BrandComponent,
    FAQComponent,
    WebinarOneComponent,
    AccomplishmentsComponent,
    AutoEditComponent,
    PowerModeEditingComponent,
    PublicationChecksComponent,
    LifeSciencesMedicineAndPharmaComponent,
    LanguageServicesPublishingAndMediaComponent,
    AcademicInstitutionsComponent,
    K12AndElearningComponent,
    TechnologyPlatformsComponent,
    AcademicPhrasebankComponent,
    AcademicPhrasebankBrowseComponent,
    HighlightKeywordsDirective,
    PaginationComponent,
    ConsistencyChecksComponent,
    PersonalDictionaryComponent,
    CreditsComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    AppRoutingModule,
    CKEditorModule,
    MaterialModule,
    MaterialModuleList,
    AppRoutingModule,
    HttpClientModule,
    NgtUniversalModule,
    ToastrModule.forRoot({
      preventDuplicates: true
    }),
    TransferHttpCacheModule,
    CommonModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

// const __stripTrailingSlash = (Location as any).stripTrailingSlash;
// Location.stripTrailingSlash = function (url) {
//   if (url.endsWith('/')) {
//     url=url;
//   }
//   else {
//     url=url+'/';
//   }
//   const queryString$ = url.match(/([^?]*)?(.*)/);
//   if (queryString$[2].length > 0) {
//     return /[^\/]\/$/.test(queryString$[1]) ? queryString$[1] + '.' + queryString$[2] : __stripTrailingSlash(url);
//   }
//   return /[^\/]\/$/.test(url) ? url + '.' : __stripTrailingSlash(url);
// };
