import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcademicPhrasebankBrowseComponent } from './academic-phrasebank-browse.component';

describe('AcademicPhrasebankBrowseComponent', () => {
  let component: AcademicPhrasebankBrowseComponent;
  let fixture: ComponentFixture<AcademicPhrasebankBrowseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AcademicPhrasebankBrowseComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcademicPhrasebankBrowseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
