import { Component, OnInit, PLATFORM_ID, Inject, ViewEncapsulation, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { isPlatformBrowser, isPlatformServer } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { WebsiteService } from 'src/app/_services/website.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Title, Meta } from '@angular/platform-browser';
import * as $ from 'jquery';
import * as AOS from 'aos';
import { LinkService } from '../../_services/langhfre.service';
import { WINDOW } from '@ng-toolkit/universal';
import { Clipboard } from "@angular/cdk/clipboard";
@Component({
  selector: 'app-academic-phrasebank-browse',
  templateUrl: './academic-phrasebank-browse.component.html',
  styleUrls: ['./academic-phrasebank-browse.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AcademicPhrasebankBrowseComponent implements OnInit {

  objectKeys = Object.keys;
  phraseBankSearchForm: FormGroup;
  navigationData: any;
  topics = {};
  phrases = null;
  currentSelection = {
    topic: '',
    subTopic: ''
  };
  isNavbarVisible = false;
  pageOfItems = {};
  pager = {
    pageSize: 10,
    pageSizeOptions: [],
    maxPages: 14
  };
  inProgress = false;

  constructor(
    private router: Router,
    private toastr: ToastrService,
    private networkCall: WebsiteService,
    private fb: FormBuilder,
    private titleService: Title,
    private metaTagService: Meta,
    @Inject(PLATFORM_ID) private platformId: Object,
    private LinkService: LinkService,
    private el: ElementRef,
    @Inject(WINDOW) private window: Window,
    private clipboard: Clipboard
  ) {
    const navigation = this.router.getCurrentNavigation();
    this.navigationData = navigation.extras.state;

    this.phraseBankSearchForm = this.fb.group({
      'sentence': [this.navigationData ? this.navigationData.sentence[0] : '', Validators.required]
    });

    if (this.navigationData) {
      this.phraseBankSearch();
    }
  }


  ngOnInit() {
    this.titleService.setTitle("Academic Phrasebank - Search");
    this.metaTagService.updateTag({ name: 'description', content: "Academic Phrasebank - Search; is a resource of invaluable phrases for all the academic writers, university students and researchers which are often used in academic and scientific writing." });
    this.metaTagService.updateTag({ property: 'og:title', content: "Academic Phrasebank - Search" });
    this.metaTagService.updateTag({ property: 'og:description', content: "Academic Phrasebank - Search; is a resource of invaluable phrases for all the academic writers, university students and researchers which are often used in academic and scientific writing." });
    this.metaTagService.updateTag({ property: 'og:url', content: 'https://www.trinka.ai/academic-phrasebank-browse/' });
    this.metaTagService.updateTag({ property: 'og:type', content: 'website' });
    this.metaTagService.updateTag({ name: 'language', content: 'en-us' });
    this.LinkService.addTag({ rel: 'canonical', href: 'https://www.trinka.ai/enterprise/academic-phrasebank-browse/' });

    if (isPlatformBrowser(this.platformId)) {
      // $.getScript('../../../assets/js/particles.min.js', function(){});
      // document.getElementById('main_header').classList.add('homepageHeader');
      $.getScript('../../../assets/js/hubslider.js', function () { });
      $.getScript('../../../assets/js/owl.carousel.min.js', function () { });
      $.getScript('../../../assets/js/wisepop.js', function () { });
      $.getScript('../../../assets/js/home_client_slider.js', function () { });
      AOS.init();
    }
    this.getPhraseBankTopics();
  }

  toggleNavbar() {
    this.isNavbarVisible = !this.isNavbarVisible;
  }

  private getPhraseBankTopics() {
    this.networkCall.getPhraseBankTopics().subscribe((response) => {
      this.topics = response;
    }, (error) => {
      console.log('getPhraseBankTopics error ===> ', error);
    });
  }

  getPhraseBankPhrases(topic, subTopic) {
    this.inProgress = true;
    this.resetForm();
    this.isNavbarVisible = false;
    this.currentSelection.topic = topic;
    this.currentSelection.subTopic = subTopic;
    this.networkCall.getPhraseBankPhrases({
      "class_name": topic,
      "new_subclass_name": subTopic
    }).subscribe((response) => {
      this.inProgress = false;
      this.phrases = response;
    }, (error) => {
      console.log('getPhraseBankPhrases error ===> ', error);
    });
  }

  phraseBankSearch() {

    if (this.phraseBankSearchForm.valid) {
      this.inProgress = true
      this.networkCall.getPhraseBankSearch({
        sentence: Object.values(this.phraseBankSearchForm.value)
      }).subscribe(response => {
        this.inProgress = false;
        this.currentSelection = {
          topic: '',
          subTopic: ''
        };
        this.collapseAllAccordions();
        this.phrases = response.result[0];
      }, error => {
        console.log('phraseBankSearch error ===> ', error);
      });
    } else {
      this.toastr.warning("Search field can not be empty");
    }
  }

  private resetForm() {
    this.phraseBankSearchForm.reset();
  }

  private collapseAllAccordions() {
    let accordionHeadings = this.el.nativeElement.querySelectorAll('.accordionHeadings, .mobile-accordionHeadings');
    let accordionBodies = this.el.nativeElement.querySelectorAll('.accordionBodies, .mobile-accordionBodies');
    accordionHeadings.forEach(element => {
      element.classList.remove('active');
    });
    accordionBodies.forEach(element => {
      element.classList.remove('show');
      element.classList.add('hide');
    });
  }

  toggleAccordion(type, index) {
    let visible = false;
    let accordionHeading = this.el.nativeElement.querySelector(`#${type}accordionHeading-${index}`);
    let accordionBody = this.el.nativeElement.querySelector(`#${type}accordionBody-${index}`);
    visible = accordionHeading.classList.value.split(' ').includes('active');
    this.collapseAllAccordions();
    if (visible) return;
    accordionHeading.classList.add('active');
    accordionBody.classList.add('show');
  }

  onChangePage(pageOfItems: Array<any>, type: string) {
    this.pageOfItems[type] = pageOfItems;
  }

  copyToClipboard(phrase: string) {
    this.toastr.success("Copied to clipboard!");
    this.clipboard.copy(phrase);
  }
}
