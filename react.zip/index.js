import { useState } from "react"
import { GraphQLClient } from "graphql-request"
import IntroFullBg from "../components/IntroFullBg"
import Service from "../components/Service"
import ContentOne from "../components/ContentOne"
import EditorProfile from "../components/EditorProfile"
import CustomerSupport from "../components/CustomerSupport"
import AdditionalBenefits from "../components/AdditionalBenefits"
import CtaService from "../components/CtaService"
import Testimonials from "../components/Testimonials"
import Faqs from "../components/Faqs"
import CtaSubmission from "../components/CtaSubmission"
import Seo from "../components/Seo"


export default function Home(props) {
  //const { API_URL } = process.env
  const pagedata = props.res.thesiseditB2BHome
  const [introData, setIntroData] = useState()
  const [serviceData, setServiceData] = useState()
  const [featureData, setFeatureData] = useState()
  const [teamData, setteamData] = useState()
  const [supportData, setSupportData] = useState()
  const [benefitsData, setBenefitsData] = useState()
  const [testimonialData, setTestimonialData] = useState()
  const [faqData, setFaqData] = useState()

  if (introData === undefined) {
    setIntroData(pagedata)
  }
  if (serviceData === undefined) {
    setServiceData(pagedata.service)
  }
  if (featureData === undefined) {
    setFeatureData(pagedata.featuresection)
  }
  if (teamData === undefined) {
    setteamData(pagedata.editorprofilesection)
  }
  if (supportData === undefined) {
    setSupportData(pagedata.statssection)
  }
  if (benefitsData === undefined) {
    setBenefitsData(pagedata.benefitssection)
  }
  if (testimonialData === undefined) {
    setTestimonialData(pagedata.testimonialsection)
  }
  if (faqData === undefined) {
    setFaqData(pagedata.faqsection)
  }


  return (
    <div>

      {pagedata && pagedata.seo && <Seo title={pagedata.seo.metatitle} description={pagedata.seo.metadescription} keyword={pagedata.seo.metakeyword} />}
      <IntroFullBg introData={introData} />

      {/* intro ends*/}
      <Service serviceData={serviceData} />
      {/* Service Section ENd */}
      <ContentOne featureData={featureData} />
      {/* Content section end */}
      <div className="bg-gray-100">
        <CtaService />
      </div>
      <EditorProfile teamData={teamData} />
      {/* Editor Profile ENd */}

      <AdditionalBenefits benefitsData={benefitsData} />
      {/* Additional Services End */}
      <CustomerSupport supportData={supportData} />
      {/* Stat Section End */}
      <Faqs faqData={faqData} />
      {/* FAQ End */}
      <Testimonials testimonialData={testimonialData} />
      {/* Testimonials End */}
      <div className="-mt-10">
        <CtaSubmission />
        </div>
    </div>
  )
}
// getServerSideProps
// getStaticProps
export async function getStaticProps() {
  const graphQlClient = new GraphQLClient(`${process.env.API_URL}/graphql`)
  const THESIS_EDITING_HOME =
    /* GraphQL */
    `
    query {
      thesiseditB2BHome{
        intro {
            title {
              title
            }
            description {
              description
            }
            bannerbackground {
              banner {
                url
                width
                height
              }
            }
          }
          service {
            sectiontitle {
              title
            }
            sectiondescription {
              description
            }
            servicecard {
              title
              description
              featured
              suitabletext
              icon {
                url
              }
            }
          }
          featuresection {
            title
            featurecard {
              title
              description
              image {
                url
              }
            }
          }
          editorprofilesection {
            title
            description
            editor {
              editorprofiles {
                id
                education
                areaofexpertise
                experience
                profileimage {
                  url
                }
                country {
                  name
                }
                profileimage {
                  url
                  width
                  height
                }
              }
            }
          }
          statssection {
            title
            description
            card {
              title
              description
              icon {
                url
              }
            }
          }
          benefitssection {
            title
            addsers {
              title
              description
              icon {
                url
              }
            }
          }
          testimonialsection {
            title
            testimonials {
              id
              testimonial
              client {
                firstname
                lastname
                clientimage {
                  url
                }
              }
            }
          }
          faqsection {
            title
            faq {
              question
              answer
            }
          }
          logosection {
            title
            logos {
              id
              url
              alternativeText
              width
              height
            }
          }
          seo {
            metatitle
            metadescription
            metakeyword
          }
        }
      }

    `
  const res = await graphQlClient.request(THESIS_EDITING_HOME)
  return {
    props: {
      res,
    },
    revalidate: 10,
  }
}
